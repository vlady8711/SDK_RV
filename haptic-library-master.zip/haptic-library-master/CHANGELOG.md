## Unity plugin 1.4.8(Nov 1st, 2019.)
* Update: Add app name to the plugin.
