## Bhaptics.Tac 1.4.2 (Dec 19th, 2018.)
* Update : Support tactosy2

## Bhaptics.Tac 1.3.0 (Apr 4th, 2018.)
* Support UWP
* Change namepsace to Bhaptics.Tact

## Bhaptics.Tac 1.2.2 (Jan 11st, 2018.)
* Add Vest rotation
* Deprecate transform

## Bhaptics.Tac 1.2.1 (Dec 13th, 2017.)
* Add IsActive(position) function on HapticPlayer

## Bhaptics.Tac 1.2.0 (Dec 11th, 2017.)
* Enable to transform on feedback file
* Enable to set number of motors on PathPoint

## Bhaptics.Tac 1.1.1 (Nov 9th, 2017.)
* Add new position type (HandL, HandR, FootL, FootR)

# Bhaptics.Tac 1.1.0 (Nov 3th, 2017.)
* Update websocket communcation between bHaptics Player
* The version of bHaptics Player should be higher or eqaul to 1.2.0
 
 # Bhaptics.Tac 1.0.2
 * Support for racket

 # Bhaptics.Tac 1.0.0
 * First Release