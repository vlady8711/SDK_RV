﻿using UnityEngine;

public class BhapticsTeleportPoint : MonoBehaviour
{
}
