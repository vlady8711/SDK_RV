﻿

namespace Bhaptics.Tact.Unity
{
    public class HandsHapticClip : ArmsHapticClip
    {
    }
}