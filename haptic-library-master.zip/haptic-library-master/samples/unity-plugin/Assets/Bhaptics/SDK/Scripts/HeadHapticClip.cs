﻿
namespace Bhaptics.Tact.Unity
{
    public class HeadHapticClip : FileHapticClip
    {
    }
}