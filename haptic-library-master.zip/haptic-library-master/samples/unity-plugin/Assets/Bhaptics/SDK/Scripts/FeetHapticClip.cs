﻿
namespace Bhaptics.Tact.Unity
{
    public class FeetHapticClip : ArmsHapticClip
    {
    }
}